
let FirstArray = [  [1,2,3,4],
					[5,6,7,8],
					[9,10,11,12],
					[13,14,15,16]
				];
window.onload = function () {
	for (var i=0; i<FirstArray.length; i++) {
		for (var j=0; j<FirstArray[i].length; j++) {
			document.getElementById("inputArray").append(FirstArray[i][j]+" ");
		}
		document.getElementById("inputArray").append(document.createElement('br'));
	}
	
	document.getElementById("Summa").append(summint);
	
	for (var i=0; i<arrayint.length; i++) {
		for (var j=0; j<arrayint[i].length; j++) {
			document.getElementById("TransposedArray").append(arrayint[i][j]+" ");
		}
		document.getElementById("TransposedArray").append(document.createElement('br'));
	}
}




//Задание 1
let summint = 0;
for (var i=0; i<FirstArray.length; i++) {
	for (var j=0; j<FirstArray[i].length; j++) {
		summint = summint + FirstArray[i][j];
	}
}
console.log("Сумма всех элементов:\n" + summint);

	
	
//Задание 2

let arrayint = [];
let sizeOfArray = 0;
for (var i=0; i<FirstArray.length; i++) {
	if (FirstArray[i].length>sizeOfArray) sizeOfArray = FirstArray[i].length;
}
for (var i=0; i<sizeOfArray; i++)
	arrayint.push([]);
for (var j=0; j<FirstArray.length; j++) {
	for (var k=0; k<FirstArray[j].length; k++) {
		arrayint[k].push(FirstArray[j][k]);
	}
}
console.log("Траспонированная матрица:");
console.log(arrayint);

	

//Задание 3
function buttonClick() {

	let MyText = document.getElementById("Text").value;
	let NumberOfUniqueSymbols = 0;
	let ArrayOfSymbols = [];
	for (var i=0; i<MyText.length; i++) 
		ArrayOfSymbols.push(true);

	for (var i=0; i<MyText.length; i++) {
		if (ArrayOfSymbols[i]==true) {
			NumberOfUniqueSymbols++;
			for (var j=i; j<MyText.length; j++) {
				if ( i!=j && MyText[i]==MyText[j] ) ArrayOfSymbols[j]=false;
			}
		}
	
	}
	console.log("Число уникальных символов:\n" + NumberOfUniqueSymbols);
	document.getElementById("UniqueSymbols").innerHTML = "Количетсво уникальных символов: " + NumberOfUniqueSymbols;
}
